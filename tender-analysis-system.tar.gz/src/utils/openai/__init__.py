"""OpenAI Chat Completions API 兼容层"""

from utils.openai.handler import OpenAIChatHandler

__all__ = ["OpenAIChatHandler"]
